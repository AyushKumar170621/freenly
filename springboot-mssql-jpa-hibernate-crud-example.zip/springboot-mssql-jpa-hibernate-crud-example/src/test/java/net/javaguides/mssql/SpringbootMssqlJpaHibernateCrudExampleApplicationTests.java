package net.javaguides.mssql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMssqlJpaHibernateCrudExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
