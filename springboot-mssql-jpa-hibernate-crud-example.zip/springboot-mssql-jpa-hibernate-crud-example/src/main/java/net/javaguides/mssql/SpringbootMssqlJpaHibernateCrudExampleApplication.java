package net.javaguides.mssql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootMssqlJpaHibernateCrudExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootMssqlJpaHibernateCrudExampleApplication.class, args);
	}

}
